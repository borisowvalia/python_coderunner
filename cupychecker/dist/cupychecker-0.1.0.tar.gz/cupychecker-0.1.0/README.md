# my_package

Простой пример Python-пакета, который выводит приветствие.

## Пример использования

```python
from my_package import say_hello

print(say_hello("World"))
```

### **LICENSE**
```text
MIT License
```